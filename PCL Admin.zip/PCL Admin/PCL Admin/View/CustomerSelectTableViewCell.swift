//
//  CustomerSelectTableViewCell.swift
//  PCL Admin
//
//  Created by NAMAN GARG on 7/6/21.
//

import UIKit

protocol CheckDelegate: Any {
    func didTapButton(sender: CustomerSelectTableViewCell)
}

class CustomerSelectTableViewCell: UITableViewCell {
    
    @IBOutlet var custNameLabel: UILabel!
    @IBOutlet var custAddLabel: UILabel!
    @IBOutlet var selectButton: UIButton!
    var checkDelegate : CheckDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    @IBAction func buttonTapped(_ sender: UIButton) {
        checkDelegate?.didTapButton(sender: self)
    }
}
