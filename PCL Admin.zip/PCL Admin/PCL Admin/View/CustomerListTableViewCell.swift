//
//  CustomerListTableViewCell.swift
//  PCL Admin
//
//  Created by NAMAN GARG on 7/2/21.
//

import UIKit

class CustomerListTableViewCell: UITableViewCell {

    @IBOutlet var idLabel: UILabel!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var addLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
