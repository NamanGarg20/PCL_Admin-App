//
//  RouteListTableViewCell.swift
//  PCL Admin
//
//  Created by Kevin on 6/30/21.
//

import UIKit

class RouteListTableViewCell: UITableViewCell {

    
    @IBOutlet var routeIdLabel: UILabel!
    @IBOutlet var routeNameLabel: UILabel!
    @IBOutlet var driverNameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
