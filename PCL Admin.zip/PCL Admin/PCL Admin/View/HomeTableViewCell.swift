//
//  HomeTableViewCell.swift
//  PCL Admin
//
//  Created by Kevin on 6/28/21.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    @IBOutlet var routeNoLabel: UILabel!
    @IBOutlet var accStatusLabel: UILabel!
    @IBOutlet var pickedUpAtLabel: UILabel!
    @IBOutlet var pickedUpByLabel: UILabel!
    @IBOutlet var specimensCollectedLabel: UILabel!
    @IBOutlet var statusLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
