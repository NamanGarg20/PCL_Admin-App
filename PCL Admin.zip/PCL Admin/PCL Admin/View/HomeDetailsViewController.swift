//
//  HomeDetailsViewController.swift
//  PCL Admin
//
//  Created by Kevin on 6/29/21.
//

import UIKit
import MapKit

class HomeDetailsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, MKMapViewDelegate {

    var routeIdSelected = -1
    var driverId = ""
    let homeDetailsVM = HomeDetailsViewModel()
    var routeData : RouteData?
    var driverLocationData : DriverLocationData?
    
    @IBOutlet var routeTableView: UITableView!
    @IBOutlet var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        mapView.mapType = .standard
        mapView.isScrollEnabled = true
        mapView.isZoomEnabled = true
        
        homeDetailsVM.getRouteInfo(routeId: routeIdSelected) { [weak self] (responseData) in
            guard let responseData = responseData else { return }
            self?.routeData = responseData
            DispatchQueue.main.async {
                self?.routeTableView.reloadData()
            }
        }
        
        homeDetailsVM.getDriverLocationInfo(driverId: driverId) { [weak self] (responseData) in
            guard let responseData = responseData else { return }
            self?.driverLocationData = responseData
            DispatchQueue.main.async {
                self?.mapThis(sourceCord: CLLocationCoordinate2D(latitude: self?.driverLocationData?[0].lat ?? 0.0, longitude: self?.driverLocationData?[0].log ?? 0.0))
            }
        }
    }
    
    func mapThis(sourceCord : CLLocationCoordinate2D) {
        let sourcePlaceMark = MKPlacemark(coordinate: sourceCord)
        
        _ = MKMapItem(placemark: sourcePlaceMark)
        
        let sourceAnnot = MKPointAnnotation()
        sourceAnnot.coordinate = sourceCord
        sourceAnnot.title = "Driver Last Location"
        mapView.addAnnotation(sourceAnnot)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        routeData?[0].customer?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = routeTableView.dequeueReusableCell(withIdentifier: "DetailsCell", for: indexPath) as! HomeDetailsTableViewCell
        
        let pickUpTime = routeData?[0].customer?[indexPath.row].pickUpTime
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy'-'MM'-'dd' 'hh':'mm' 'a"
        let date = dateFormatter.date(from: pickUpTime!)
        dateFormatter.dateStyle = .none
        dateFormatter.timeStyle = .short
        let displayTime = date == nil ? pickUpTime : dateFormatter.string(from: date!)
        
        let streetAddress = (routeData?[0].customer?[indexPath.row].streetAddress)!
        let city = (routeData?[0].customer?[indexPath.row].city)!
        let state = (routeData?[0].customer?[indexPath.row].state)!
        let zip = (routeData?[0].customer?[indexPath.row].zip)!
        let addLbl = streetAddress + " " + city + " " + state + " " + zip
        
        cell.custNameLabel.text = routeData?[0].customer?[indexPath.row].customerName
        cell.custIdLabel.text = "\(routeData?[0].customer?[indexPath.row].customerID ?? 0)"
        cell.addLabel.text = addLbl
        cell.specCollectLabel.text = "Specimens Collected : \(routeData?[0].customer?[indexPath.row].specimensCollected ?? 0)"
        
        cell.statusLabel.text = routeData?[0].customer?[indexPath.row].collectionStatus
        cell.timeLabel.text = displayTime
        
        return cell
    }

}
