//
//  RouteViewController.swift
//  PCL Admin
//
//  Created by NAMAN GARG on 7/2/21.
//

import UIKit

protocol DropDownDelegate {
    func selectedDriver(_ driver: DriverListDatum)
    func selectedVehicle(_ vehicle: VehicleListDatum)
    func selectedCustomer(_ custIds: String, _ custArray: [Int], _ custObj : CustomerListData)
}

class RouteViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var results: APIResults?
    var routeObject : RoutesListDatum?
    var routeVM  = AddUpdateViewModel()
    var segueId = -1
    var delegate : DismissDelegate?
    var custIds = ""
    var segueNo = -1
    var custArray = [Int]()
    var selCustList : CustomerListData?
    
    var driverObject : DriverListDatum?
    var vehicleObject : VehicleListDatum?
    var customerObject: CustomerListDatum?
    
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var routeNoLabel: UILabel!
    @IBOutlet var routeNametextField: UITextField!
    
    @IBOutlet var driverNameButton: UIButton!
    @IBOutlet var VehicleNoButton: UIButton!
    
    @IBOutlet var tableView: UITableView!
    @IBOutlet var addButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        routeNoLabel.layer.borderWidth = 1.0
        routeNoLabel.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        routeNametextField.layer.borderWidth = 1.0
        routeNametextField.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        tableView.layer.borderWidth = 1.0
        tableView.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        driverNameButton.layer.borderWidth = 1.0
        driverNameButton.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        
        VehicleNoButton.layer.borderWidth = 1.0
        VehicleNoButton.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        displayInfo()
    }
    
    func displayInfo() {
        switch segueId {
        case 0:
            titleLabel.text = "Add Route"
            addButton.setTitle("Add", for: UIControl.State.normal)
        case 1:
            titleLabel.text = "Update Route"
            addButton.setTitle("Update", for: UIControl.State.normal)
            routeNoLabel.text = "Route Id: \(routeObject?.route?.routeNo ?? 0)"
            routeNametextField.text = routeObject?.route?.routeName
            driverNameButton.setTitle(routeObject?.route?.driverName, for: UIControl.State.normal)
            
            VehicleNoButton.setTitle(routeObject?.route?.vehicleNo, for: UIControl.State.normal)
        default:
            return
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch segueId {
        case 0:
            return custArray.count + 1
        case 1:
            if custArray.isEmpty {
                return (routeObject?.customer?.count)! + 1
            } else {
                return (routeObject?.customer?.count)! + custArray.count + 1
            }
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if segueId == 0{
            routeObject = nil
        }
        
        if indexPath.row == ((routeObject?.customer!.count ?? 0) +  custArray.count) {
            let addcell = tableView.dequeueReusableCell(withIdentifier: "addCustomCell")
            return addcell!
        } else if custArray.isEmpty && segueId == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "addRouteCell") as! CustomerListTableViewCell
            var address = ""
            if let street = routeObject?.customer?[indexPath.row].streetAddress {
                
                address  = street + " " + (routeObject?.customer?[indexPath.row].city)! + " " + (routeObject?.customer?[indexPath.row].state)! + " " + (routeObject?.customer?[indexPath.row].zip)!
                
            }
            
            cell.idLabel.text = "\(indexPath.row + 1)"
            cell.nameLabel.text = routeObject?.customer?[indexPath.row].customerName
            cell.addLabel.text = address
            
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "addRouteCell") as! CustomerListTableViewCell
            var address = ""
            var count = 0
            if segueId == 1{
                count = (routeObject?.customer?.count) ?? 0
            }
            
            if indexPath.row >= 0 && indexPath.row < count && segueId == 1 {
                
                if let street = routeObject?.customer?[indexPath.row].streetAddress {
                    address  = street + " " + (routeObject?.customer?[indexPath.row].city)! + " " + (routeObject?.customer?[indexPath.row].state)! + " " + (routeObject?.customer?[indexPath.row].zip)!
                }
                
                cell.idLabel.text = "\(indexPath.row + 1)"
                cell.nameLabel.text = routeObject?.customer?[indexPath.row].customerName
                cell.addLabel.text = address
                
            } else if indexPath.row >= count && indexPath.row < (count + custArray.count) {
                
                
                for i in (selCustList)! {
                    if i.customerID == custArray[indexPath.row - count] {
                        address  = (i.streetAddress)! + " " + (i.city)! + " " + (i.state)! + " " + (i.zip)!
                        
                        cell.idLabel.text = "\(indexPath.row + 1)"
                        cell.nameLabel.text = i.customerName
                        cell.addLabel.text = address
                    }
                }
            }
            return cell
        }
    }
    
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        var customerString = ""
        for i in 0...((routeObject?.customer?.count)!-1) {
            if (i) != indexPath.row{
                customerString += "\((routeObject?.customer?[i].customerID)!),"
            }
            
        }
        
        customerString = String(customerString.dropLast(1))
        
        let deleteAction = UIContextualAction(style: UIContextualAction.Style.destructive, title: "Delete", handler: {(_,_,_) in self.routeVM.updateRoute(customerID: customerString, vehicleNo: (self.VehicleNoButton.titleLabel?.text)!, routeName: self.routeNametextField.text!, driverId: (self.routeObject?.route?.driverID)!, routeNo: (self.routeObject?.route?.routeNo)!) { [weak self] (results) in
            guard let results = results else { return }
            self?.results = results
            
            if self?.results?.result == "Success" || self?.results?.result == "success" {
                self?.delegate?.dismissPop()
                DispatchQueue.main.async {
                    self?.dismiss(animated: true, completion: nil)
                }
            } else {
                DispatchQueue.main.async {
                    self?.dispAlert((self?.results?.result)!)
                }
            }
        }
        tableView.reloadData()
        })
        
        let swipeGestureAction = UISwipeActionsConfiguration(actions: [deleteAction])
        return swipeGestureAction
    }
    
    func dispAlert(_ msg: String){
        let alert = UIAlertController(title: "Error", message: msg, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { action -> Void in }
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func addAction(_ sender: UIButton) {
        switch segueId {
        case 0:
            routeVM.addRoute(customerID: custIds, vehicleNo: (VehicleNoButton.titleLabel?.text)!, routeName: routeNametextField.text!, driverId: (driverObject?.driverID)!) { [weak self] (results) in
                guard let results = results else { return }
                self?.results = results
                if self?.results?.result == "Success" || self?.results?.result == "success" {
                    DispatchQueue.main.async {
                        self?.delegate?.dismissPop()
                        self?.dismiss(animated: true, completion: nil)
                    }
                } else {
                    DispatchQueue.main.async {
                        self?.dispAlert((self?.results?.result)!)
                    }
                }
            }
            
        case 1:
            if !custIds.isEmpty {
                custIds += ","
            }
            for i in (routeObject?.customer)!{
                custIds += "\(i.customerID!),"
            }
            if !custIds.isEmpty {
                custIds = String(custIds.dropLast(1))
            }
            
            let driverId = driverObject?.driverID != nil ? (driverObject?.driverID)! : (routeObject?.route?.driverID)!
            
            routeVM.updateRoute(customerID: custIds, vehicleNo: (VehicleNoButton.titleLabel?.text)!, routeName: routeNametextField.text!, driverId: driverId, routeNo: (routeObject?.route?.routeNo)!) { [weak self] (results) in
                guard let results = results else { return }
                self?.results = results
                if self?.results?.result == "Success" || self?.results?.result == "success" {
                    DispatchQueue.main.async {
                        self?.delegate?.dismissPop()
                        self?.dismiss(animated: true, completion: nil)
                    }
                } else {
                    DispatchQueue.main.async {
                        self?.dispAlert((self?.results?.result)!)
                    }
                }
            }
        default:
            return
        }
    }
    
    
    
    @IBAction func cancelAction(_ sender: UIButton) {
        self.custArray = []
        self.custIds = ""
        self.selCustList = nil
        self.dismiss(animated: true, completion: nil)
        delegate?.dismissPop()
    }
    
    @IBAction func driverAction(_ sender: UIButton) {
        segueNo = 0
        performSegue(withIdentifier: "showDriverSegue", sender: self)
    }
    
    
    @IBAction func vehicleAction(_ sender: UIButton) {
        segueNo = 1
        performSegue(withIdentifier: "showVehicleSegue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDriverSegue" || segue.identifier == "showVehicleSegue" {
            let nextVC = segue.destination as! DropDownListTableViewController
            nextVC.segueNo = segueNo
            nextVC.selectDelegate = self
        } else if segue.identifier == "showCustomer" {
            let nextVC = segue.destination as! CustomerListTableViewController
            nextVC.custDelegate = self
        }
        
    }
    
}

extension RouteViewController : DropDownDelegate {
    func selectedCustomer(_ custIds: String, _ custArray: [Int], _ custObj: CustomerListData) {
        self.custIds = custIds
        self.custArray = custArray
        self.selCustList = custObj
        self.tableView.reloadData()
    }
    
    func selectedDriver(_ driver: DriverListDatum) {
        self.driverObject = driver
        self.driverNameButton.setTitle(driverObject?.driverName, for: .normal)
    }
    
    func selectedVehicle(_ vehicle: VehicleListDatum) {
        self.vehicleObject = vehicle
        self.VehicleNoButton.setTitle(vehicleObject?.plateNumber, for: .normal)
    }
}

