//
//  CustomerListTableViewController.swift
//  PCL Admin
//
//  Created by NAMAN GARG on 7/6/21.
//

import UIKit

class CustomerListTableViewController: UITableViewController {
    var customerList : CustomerListData?
    var customerObject: CustomerListDatum?
    var dropDownListViewModel = DropDownListViewModel()
    var checkBool : [Bool] = []
    var custIds = ""
    var custIdArray = [Int]()
    var custDelegate : DropDownDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
    }
    
    func getData(){
        dropDownListViewModel.getAvailableCustomerList { [weak self] (responseData) in
            guard let responseData = responseData else { return }
            self?.customerList = responseData
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return customerList?.count ?? 0
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomerCell", for: indexPath) as! CustomerSelectTableViewCell

        cell.custNameLabel.text = customerList?[indexPath.row].customerName
        let address = (customerList?[indexPath.row].streetAddress)! + " " + (customerList?[indexPath.row].city)! + " " + (customerList?[indexPath.row].state)! + " " + String((customerList?[indexPath.row].zip)!)
        
        cell.custAddLabel.text = address
        checkBool.append(false)
        cell.selectButton.isSelected = checkBool[indexPath.row]
        cell.checkDelegate = self
        return cell
    }
    
    func checkButton(_ index: Int) -> Bool {
        if checkBool[index] == false {
            checkBool[index] = true
            return(true)
        }
        else if checkBool[index] == true {
            checkBool[index] = false
            return(false)
        }
        return false
    }
    
    @IBAction func addAction(_ sender: UIButton) {
        for i in 0...(checkBool.count-1) {
            if checkBool[i] == true {
                custIds += "\((customerList![i].customerID)!),"
                custIdArray.append((customerList![i].customerID)!)
            }
        }
        
        custIds = String(custIds.dropLast(1))
        custDelegate?.selectedCustomer(custIds,custIdArray, customerList!)
        self.dismiss(animated: true, completion: nil)
    }
}

extension CustomerListTableViewController : CheckDelegate {
    func didTapButton(sender: CustomerSelectTableViewCell) {
        if let selectedIndexPath = tableView.indexPath(for: sender) {
            checkBool[selectedIndexPath.row] = !checkBool[selectedIndexPath.row]
            tableView.reloadRows(at: [selectedIndexPath], with: .automatic)
        }
    }
    
    
}
