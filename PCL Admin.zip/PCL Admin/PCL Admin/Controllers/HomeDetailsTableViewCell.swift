//
//  HomeDetailsTableViewCell.swift
//  PCL Admin
//
//  Created by Kevin on 6/29/21.
//

import UIKit

class HomeDetailsTableViewCell: UITableViewCell {

    @IBOutlet var custNameLabel: UILabel!
    @IBOutlet var addLabel: UILabel!
    @IBOutlet var specCollectLabel: UILabel!
    @IBOutlet var timeLabel: UILabel!
    @IBOutlet var statusLabel: UILabel!
    @IBOutlet var custIdLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
