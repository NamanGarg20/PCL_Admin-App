//
//  DropDownListTableViewController.swift
//  PCL Admin
//
//  Created by NAMAN GARG on 7/6/21.
//

import UIKit

class DropDownListTableViewController: UITableViewController {
    
    var driverList : DriverListData?
    var vehicleList : VehicleListData?
    var dropDownListViewModel = DropDownListViewModel()
    var segueNo = -1
    var segueId = -1
    
    var selectDelegate: DropDownDelegate?
    
    var driverObject : DriverListDatum?
    var vehicleObject : VehicleListDatum?
    

    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
    }
    
    func getData(){
        switch segueNo {
        case 0:
            dropDownListViewModel.getAvailableDriverList {[weak self] (responseData) in
                guard let responseData = responseData else { return }
                self?.driverList = responseData
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            }
        case 1:
            dropDownListViewModel.getAvailableVehicleList { [weak self] (responseData) in
                guard let responseData = responseData else { return }
                self?.vehicleList = responseData
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            }
        
        default:
            return
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        switch segueNo {
        case 0:
            return driverList?.count ?? 0
        case 1:
            return vehicleList?.count ?? 0
        default:
            return 0
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "dropDownCell", for: indexPath)

        switch segueNo {
        case 0:
            cell.textLabel?.text = driverList?[indexPath.row].driverName
        case 1:
            cell.textLabel?.text = vehicleList?[indexPath.row].plateNumber
        default:
            cell.textLabel?.text = ""
        }

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch segueNo {
        case 0:
            segueId = 1
            driverObject = driverList?[indexPath.row]
            selectDelegate?.selectedDriver(driverObject!)
            self.dismiss(animated: true, completion: nil)
        case 1:
            segueId = 1
            vehicleObject = vehicleList?[indexPath.row]
            selectDelegate?.selectedVehicle(vehicleObject!)
            self.dismiss(animated: true, completion: nil)
        default:
            return
        }
    }

}
