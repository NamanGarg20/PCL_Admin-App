//
//  SettingsTableViewController.swift
//  PCL Admin
//
//  Created by Kevin on 6/28/21.
//

import UIKit

class SettingsTableViewController: UITableViewController {
    
    let tableData = ["Driver","Customer","Vehicle","Routes"]
    var selectedRow = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = tableData[indexPath.row]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedRow = indexPath.row
        
        switch selectedRow {
        case 0:
            performSegue(withIdentifier: "driverSegue", sender: self)
        case 1:
            performSegue(withIdentifier: "customerSegue", sender: self)
        case 2:
            performSegue(withIdentifier: "vehicleSegue", sender: self)
        case 3:
            performSegue(withIdentifier: "routesSegue", sender: self)
        default:
            return
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if selectedRow == 3 {
            _ = segue.destination as! RouteListTableViewController
        } else {
            let nextVC = segue.destination as! ListTableViewController
            switch selectedRow {
            case 0:
                nextVC.segueNo = 0
            case 1:
                nextVC.segueNo = 1
            case 2:
                nextVC.segueNo = 2
            default:
                return
            }
        }
    }
}
