//
//  AddCustomerViewController.swift
//  PCL Admin
//
//  Created by Kevin on 6/28/21.
//

import UIKit

class CustomerViewController: UIViewController {
    var results: APIResults?
    var customerObject : CustomerListDatum?
    var customerVM  = AddUpdateViewModel()
    var segueId = -1
    var delegate : DismissDelegate?
    var custDate = ""
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var customerNameTextField: UITextField!
    @IBOutlet var streetTextField: UITextField!
    @IBOutlet var cityTextField: UITextField!
    @IBOutlet var stateTextField: UITextField!
    @IBOutlet var zipTextField: UITextField!
    @IBOutlet var timePicker: UIDatePicker!
    @IBOutlet var addButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        customerNameTextField.layer.borderWidth = 1.0
        customerNameTextField.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        streetTextField.layer.borderWidth = 1.0
        streetTextField.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        cityTextField.layer.borderWidth = 1.0
        cityTextField.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        stateTextField.layer.borderWidth = 1.0
        stateTextField.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        zipTextField.layer.borderWidth = 1.0
        zipTextField.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        timePicker.layer.borderWidth = 1.0
        timePicker.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        
        displayInfo()
        
    }
    
    func displayInfo() {
        switch segueId {
        case 0:
            titleLabel.text = "Add Customer"
            addButton.setTitle("Add", for: UIControl.State.normal)
        case 1:
            let lastTime = customerObject?.pickUpTime
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy'-'MM'-'dd' 'hh':'mm' 'a"
            let date = dateFormatter.date(from: lastTime!)
            dateFormatter.dateStyle = .none
            dateFormatter.timeStyle = .short
            
            timePicker.setDate(date!, animated: true)
            titleLabel.text = "Update Customer"
            addButton.setTitle("Update", for: UIControl.State.normal)
            customerNameTextField.text = customerObject?.customerName
            streetTextField.text = customerObject?.streetAddress
            cityTextField.text = customerObject?.city
            zipTextField.text = customerObject?.zip
            stateTextField.text = customerObject?.state
        default:
            return
        }
    }
    
    @IBAction func timeChangedAction(_ sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = DateFormatter.Style.none
        dateFormatter.timeStyle = DateFormatter.Style.short
        dateFormatter.dateFormat = "hh':'mm' 'a"
        custDate = dateFormatter.string(from: timePicker.date)
    }
    
    @IBAction func resetActionButton(_ sender: UIButton) {
        switch segueId {
        case 0:
            customerNameTextField.text = ""
            streetTextField.text = ""
            cityTextField.text = ""
            zipTextField.text = ""
            stateTextField.text = ""
        case 1:
            let lastTime = customerObject?.pickUpTime
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy'-'MM'-'dd' 'hh':'mm' 'a"
            let date = dateFormatter.date(from: lastTime!)
            dateFormatter.dateStyle = .none
            dateFormatter.timeStyle = .short
            
            timePicker.setDate(date!, animated: true)
            customerNameTextField.text = customerObject?.customerName
            streetTextField.text = customerObject?.streetAddress
            cityTextField.text = customerObject?.city
            zipTextField.text = customerObject?.zip
            stateTextField.text = customerObject?.state
        default:
            return
            
        }
    }
    
    @IBAction func cancelButtonAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addButtonAction(_ sender: UIButton) {
        if customerNameTextField.text != "" && streetTextField.text != "" && cityTextField.text != "" && zipTextField.text != "" && stateTextField.text != "" {
            switch  segueId{
            case 0:
                customerVM.addCustomer(city: cityTextField.text!, customerName: customerNameTextField.text!, pickUp: custDate, state: stateTextField.text!, streetAddress: streetTextField.text!, zip: Int(zipTextField.text!)!) { [weak self] (results) in
                    guard let results = results else { return }
                    self?.results = results
                    if self?.results?.result == "Success" || self?.results?.result == "success" {
                        DispatchQueue.main.async {
                            self?.delegate?.dismissPop()
                            self?.dismiss(animated: true, completion: nil)
                        }
                    } else {
                        DispatchQueue.main.async {
                            self?.dispAlert((self?.results?.result)!)
                        }
                    }
                }
            case 1:
                customerVM.updateCustomer(custId: (customerObject?.customerID)!, city: cityTextField.text!, customerName: customerNameTextField.text!, pickUp: custDate, state: stateTextField.text!, streetAddress: streetTextField.text!, zip: Int(zipTextField.text!)!) { [weak self] (results) in
                    guard let results = results else { return }
                    self?.results = results
                    if self?.results?.result == "Success" || self?.results?.result == "success" {
                        DispatchQueue.main.async {
                            self?.delegate?.dismissPop()
                            self?.dismiss(animated: true, completion: nil)
                        }
                    } else {
                        DispatchQueue.main.async {
                            self?.dispAlert((self?.results?.result)!)
                        }
                    }
                }
            default:
                return
            }
        }
        else{
            dispAlert("All Fields Required.")
        }
    }
    
    func dispAlert(_ msg: String){
        let alert = UIAlertController(title: "Error", message: msg, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { action -> Void in }
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
}
