//
//  VehicleViewController.swift
//  PCL Admin
//
//  Created by Kevin on 7/1/21.
//

import UIKit

class VehicleViewController: UIViewController {

    var results: APIResults?
    var vehicleObject : VehicleListDatum?
    var vehicleVM  = AddUpdateViewModel()
    var segueId = -1
    var delegate : DismissDelegate?
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var plateNoTextField: UITextField!
    @IBOutlet var vehicleMakeTextField: UITextField!
    @IBOutlet var vehicleModelTextField: UITextField!
    @IBOutlet var addButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        plateNoTextField.layer.borderWidth = 1.0
        plateNoTextField.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        vehicleMakeTextField.layer.borderWidth = 1.0
        vehicleMakeTextField.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        vehicleModelTextField.layer.borderWidth = 1.0
        vehicleModelTextField.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        displayInfo()
    }
    
    func displayInfo() {
        switch segueId {
        case 0:
            titleLabel.text = "Add Vehicle"
            addButton.setTitle("Add", for: UIControl.State.normal)
        case 1:
            titleLabel.text = "Update Vehicle"
            addButton.setTitle("Update", for: UIControl.State.normal)
            plateNoTextField.text = vehicleObject?.plateNumber
            vehicleMakeTextField.text = vehicleObject?.manufacturer
            vehicleModelTextField.text = vehicleObject?.model
        default:
            return
        }
    }

    @IBAction func resetAction(_ sender: UIButton) {
        switch segueId {
        case 0:
            plateNoTextField.text = ""
            vehicleMakeTextField.text = ""
            vehicleModelTextField.text = ""
        case 1:
            plateNoTextField.text = vehicleObject?.plateNumber
            vehicleMakeTextField.text = vehicleObject?.manufacturer
            vehicleModelTextField.text = vehicleObject?.model
        default:
            return
            
        }
    }
    
    @IBAction func cancelAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addAction(_ sender: UIButton) {
        if plateNoTextField.text != "" && vehicleMakeTextField.text != "" && vehicleModelTextField.text != ""{
            switch  segueId{
            case 0:
                vehicleVM.addVehicle(manufacturer: vehicleMakeTextField.text!, model: vehicleModelTextField.text!, plateNum: plateNoTextField.text!) { [weak self] (results) in
                    guard let results = results else { return }
                    self?.results = results
                    if self?.results?.result == "Success" || self?.results?.result == "success" {
                        DispatchQueue.main.async {
                            self?.delegate?.dismissPop()
                            self?.dismiss(animated: true, completion: nil)
                        }
                        
                    } else {
                        DispatchQueue.main.async {
                            self?.dispAlert((self?.results?.result)!)
                        }
                    }
                }
            case 1:
                
                vehicleVM.updateVehicle(manufacturer: vehicleMakeTextField.text!, model: vehicleModelTextField.text!, plateNum: plateNoTextField.text!, vehicleId: (vehicleObject?.vehicleID)!) { [weak self] (results) in
                    guard let results = results else { return }
                    self?.results = results
                    if self?.results?.result == "Success" || self?.results?.result == "success" {
                        DispatchQueue.main.async {
                            self?.delegate?.dismissPop()
                            self?.dismiss(animated: true, completion: nil)
                        }
                    } else {
                        DispatchQueue.main.async {
                            self?.dispAlert((self?.results?.result)!)
                        }
                    }
                }
            default:
                return
            }
        } else{
            dispAlert("All Fields Required.")
        }
    }
    
    func dispAlert(_ msg: String){
        let alert = UIAlertController(title: "Error", message: msg, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { action -> Void in }
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
}
