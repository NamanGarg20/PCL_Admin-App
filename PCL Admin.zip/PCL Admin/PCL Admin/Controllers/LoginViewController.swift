//
//  LoginViewController.swift
//  PCL Admin
//
//  Created by Kevin on 7/12/21.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet var usernameTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    var results : APIResults?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func loginAction(_ sender: UIButton) {
        if usernameTextField.text != nil && passwordTextField != nil {
            ApiManager.loginUser(user: usernameTextField.text!, pass: passwordTextField.text!) { [weak self] (responseData, error) in
                if let data = responseData {
                    self?.results = data
                    DispatchQueue.main.async {
                        self?.nextScreenOrAlert()
                    }
                }
            }
        }
        
    }
    
    func nextScreenOrAlert(){
        let res = "\(results?.result! ?? "None")"
        if res.contains("Login successful") {
            let scene = self.view.window?.windowScene?.delegate as? SceneDelegate
            scene?.openTabView()
        } else {
            let alert = UIAlertController(title: "Error", message: res, preferredStyle: .alert)
            let okButton = UIAlertAction(title: "OK", style: .default) {
                action -> Void in
            }
            alert.addAction(okButton)
            self.present(alert, animated: true, completion: nil)
        }
    }
}
