//
//  RouteListTableViewController.swift
//  PCL Admin
//
//  Created by Kevin on 6/30/21.
//

import UIKit

class RouteListTableViewController: UITableViewController {
    
    var routeList : RouteListData?
    var results : APIResults?
    var listTableVM = ListTableViewModel()
    var segueId = -1
    var routeObject : RoutesListDatum?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    func getData() {
        listTableVM.getRoutesList { [weak self] (responseData) in
            guard let responseData = responseData else { return }
            self?.routeList = responseData
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
        }
    }
    // MARK: - Table view data source
    
    @IBAction func addBarButton(_ sender: UIBarButtonItem) {
        segueId = 0
        performSegue(withIdentifier: "addRouteSegue", sender: self)
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return routeList?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "routeCell", for: indexPath) as! RouteListTableViewCell
        cell.routeNameLabel.text = routeList?[indexPath.row].route?.routeName
        cell.routeIdLabel.text = "\(routeList?[indexPath.row].route?.routeNo ?? 0)"
        cell.driverNameLabel.text = routeList?[indexPath.row].route?.driverName
        return cell
    }
    
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: UIContextualAction.Style.destructive, title: "Delete", handler: {(_,_,_) in self.listTableVM.delRoute(routeNo: (self.routeList?[indexPath.row].route?.routeNo)!) { [weak self] (results) in
            guard let results = results else { return }
            self?.results = results
            if self?.results?.result == "Success" || self?.results?.result == "success" {
                self?.getData()
            } else {
                DispatchQueue.main.async {
                    self?.dispAlert((self?.results?.result)!)
                }
            }
        }
        tableView.reloadData()
        })
        
        let swipeGestureAction = UISwipeActionsConfiguration(actions: [deleteAction])
        return swipeGestureAction
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        routeObject = routeList?[indexPath.row]
        segueId = 1
        performSegue(withIdentifier: "updateRouteSegue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let nextVC = segue.destination as! RouteViewController
        nextVC.segueId = segueId
        nextVC.delegate = self
        nextVC.routeObject = routeObject
    }
    
    func dispAlert(_ msg: String){
        let alert = UIAlertController(title: "Error", message: msg, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { action -> Void in }
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
}

extension RouteListTableViewController : DismissDelegate {
    func dismissPop() {
        self.getData()
    }
}
