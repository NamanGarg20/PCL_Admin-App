//
//  ListTableViewController.swift
//  PCL Admin
//
//  Created by Kevin on 6/30/21.
//

import UIKit

protocol DismissDelegate {
    func dismissPop()
}

class ListTableViewController: UITableViewController {
    
    var segueNo = -1
    var driverList : DriverListData?
    var customerList : CustomerListData?
    var vehicleList : VehicleListData?
    var results : APIResults?
    var listTableVM = ListTableViewModel()
    var segueId = -1
    var driverObject : DriverListDatum?
    var vehicleObject : VehicleListDatum?
    var customerObject : CustomerListDatum?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
    }
    
    func getData(){
        switch segueNo {
        case 0:
            listTableVM.getDriverList { [weak self] (responseData) in
                guard let responseData = responseData else { return }
                self?.driverList = responseData
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            }
        case 1:
            listTableVM.getCustomerList { [weak self] (responseData) in
                guard let responseData = responseData else { return }
                self?.customerList = responseData
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            }
        case 2:
            listTableVM.getVehicleList { [weak self] (responseData) in
                guard let responseData = responseData else { return }
                self?.vehicleList = responseData
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            }
        default:
            return
        }
    }
    
    @IBAction func addBarButton(_ sender: UIBarButtonItem) {
        switch segueNo {
        case 0:
            segueId = 0
            performSegue(withIdentifier: "addDriverSegue", sender: self)
        case 1:
            segueId = 0
            performSegue(withIdentifier: "addCustomerSegue", sender: self)
        case 2:
            segueId = 0
            performSegue(withIdentifier: "addVehicleSegue", sender: self)
        default:
            print("")
        }
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch segueNo {
        case 0:
            return driverList?.count ?? 0
        case 1:
            return customerList?.count ?? 0
        case 2:
            return vehicleList?.count ?? 0
        default:
            return 0
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        
        switch segueNo {
        case 0:
            cell.textLabel?.text = driverList?[indexPath.row].driverName
        case 1:
            cell.textLabel?.text = customerList?[indexPath.row].customerName
        case 2:
            cell.textLabel?.text = vehicleList?[indexPath.row].plateNumber
        default:
            cell.textLabel?.text = ""
        }
        
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        var deleteAction = UIContextualAction()
        switch segueNo {
        case 0:
            deleteAction = UIContextualAction(style: UIContextualAction.Style.destructive, title: "Delete", handler: {(_,_,_) in self.listTableVM.delDriver(driverId: (self.driverList?[indexPath.row].driverID)!) { [weak self] (results) in
                guard let results = results else { return }
                self?.results = results
                if self?.results?.result == "Success" || self?.results?.result == "success" {
                    self?.getData()
                } else {
                    DispatchQueue.main.async {
                        self?.dispAlert((self?.results?.result)!)
                    }
                }
            }
            tableView.reloadData()
            })
        case 1:
            deleteAction = UIContextualAction(style: UIContextualAction.Style.destructive, title: "Delete", handler: {(_,_,_) in self.listTableVM.delCustomer(custId: (self.customerList?[indexPath.row].customerID)!) { [weak self] (results) in
                guard let results = results else { return }
                self?.results = results
                if self?.results?.result == "Success" || self?.results?.result == "success" {
                    self?.getData()
                } else {
                    DispatchQueue.main.async {
                        self?.dispAlert((self?.results?.result)!)
                    }
                }
            }
            tableView.reloadData()
            })
        case 2:
            deleteAction = UIContextualAction(style: UIContextualAction.Style.destructive, title: "Delete", handler: {(_,_,_) in self.listTableVM.delVehicle(vehicleId: (self.vehicleList?[indexPath.row].vehicleID)!) { [weak self] (results) in
                guard let results = results else { return }
                self?.results = results
                if self?.results?.result == "Success" || self?.results?.result == "success" {
                    self?.getData()
                } else {
                    DispatchQueue.main.async {
                        self?.dispAlert((self?.results?.result)!)
                    }
                }
            }
            tableView.reloadData()
            })
        default:
            tableView.reloadData()
        }
        
        let swipeGestureAction = UISwipeActionsConfiguration(actions: [deleteAction])
        return swipeGestureAction
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch segueNo {
        case 0:
            segueId = 1
            driverObject = driverList?[indexPath.row]
            performSegue(withIdentifier: "updateDriverSegue", sender: self)
        case 1:
            segueId = 1
            customerObject = customerList?[indexPath.row]
            performSegue(withIdentifier: "updateCustomerSegue", sender: self)
        case 2:
            segueId = 1
            vehicleObject = vehicleList?[indexPath.row]
            performSegue(withIdentifier: "updateVehicleSegue", sender: self)
        default:
            return
        }
    }
    
    func dispAlert(_ msg: String){
        let alert = UIAlertController(title: "Error", message: msg, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { action -> Void in }
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segueNo {
        case 0:
            let nextVC = segue.destination as! DriverViewController
            nextVC.segueId = segueId
            nextVC.driverObject = driverObject
            nextVC.delegate = self
        case 1:
            let nextVC = segue.destination as! CustomerViewController
            nextVC.customerObject = customerObject
            nextVC.segueId = segueId
            nextVC.delegate = self
            
        case 2:
            let nextVC = segue.destination as! VehicleViewController
            nextVC.segueId = segueId
            nextVC.vehicleObject = vehicleObject
            nextVC.delegate = self
        default:
            return
        }
    }
}

extension ListTableViewController : DismissDelegate {
    func dismissPop() {
        self.getData()
    }
}
