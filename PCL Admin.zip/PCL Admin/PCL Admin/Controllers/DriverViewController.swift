//
//  AddDriverViewController.swift
//  PCL Admin
//
//  Created by Kevin on 6/28/21.
//

import UIKit

class DriverViewController: UIViewController {

    var results : APIResults?
    var driverVM = AddUpdateViewModel()
    var segueId = -1
    var delegate : DismissDelegate?
    var driverObject : DriverListDatum?
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var firstNameTextFIeld: UITextField!
    @IBOutlet var lastNameTextField: UITextField!
    @IBOutlet var phoneNoTextField: UITextField!
    @IBOutlet var addButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        displayInfo()
        firstNameTextFIeld.layer.borderWidth = 1.0
        firstNameTextFIeld.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        lastNameTextField.layer.borderWidth = 1.0
        lastNameTextField.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
        
        phoneNoTextField.layer.borderWidth = 1.0
        phoneNoTextField.layer.borderColor = CGColor(red: (106/255.0), green: (12/255.0), blue: (35/255.0), alpha: 1.0)
    }
    
    func displayInfo() {
        switch segueId {
        case 0:
            titleLabel.text = "Add Driver"
            addButton.setTitle("Add", for: UIControl.State.normal)
        case 1:
            titleLabel.text = "Update Driver"
            addButton.setTitle("Update", for: UIControl.State.normal)
            let name = driverObject?.driverName?.split(separator: " ")
            firstNameTextFIeld.text = String(name![0])
            lastNameTextField.text = String(name![1])
            phoneNoTextField.text = driverObject?.phoneNumber
        default:
            return
        }
    }
    
    @IBAction func resetActionButton(_ sender: UIButton) {
        switch segueId {
        case 0:
            firstNameTextFIeld.text = ""
            lastNameTextField.text = ""
            phoneNoTextField.text = ""
        case 1:
            let name = driverObject?.driverName?.split(separator: " ")
            firstNameTextFIeld.text = String(name![0])
            lastNameTextField.text = String(name![1])
            phoneNoTextField.text = driverObject?.phoneNumber
        default:
            return
        }
    }
    
    @IBAction func cancelActionButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addActionButton(_ sender: UIButton) {
        if firstNameTextFIeld.text != "" && lastNameTextField.text != "" && phoneNoTextField.text != "" {
            switch segueId {
            case 0:
                driverVM.addDriver(firstName: firstNameTextFIeld.text!, lastName: lastNameTextField.text!, phoneNo: phoneNoTextField.text!) { [weak self] (results) in
                    guard let results = results else { return }
                    self?.results = results
                    if self?.results?.result == "Success" || self?.results?.result == "success" {
                        DispatchQueue.main.async {
                            self?.delegate?.dismissPop()
                            self?.dismiss(animated: true, completion: nil)
                        }
                    } else {
                        DispatchQueue.main.async {
                            self?.dispAlert((self?.results?.result)!)
                        }
                    }
                }
            case 1:
                driverVM.updateDriver(driverId: (driverObject?.driverID)!, firstName: firstNameTextFIeld.text!, lastName: lastNameTextField.text!, phoneNo: phoneNoTextField.text!) { [weak self] (results) in
                    guard let results = results else { return }
                    self?.results = results
                    if self?.results?.result == "Success" || self?.results?.result == "success" {
                        DispatchQueue.main.async {
                            self?.delegate?.dismissPop()
                            self?.dismiss(animated: true, completion: nil)
                        }
                    } else {
                        DispatchQueue.main.async {
                            self?.dispAlert((self?.results?.result)!)
                        }
                    }
                }
            default:
                return
            }
        } else {
            dispAlert("All Fields Required.")
        }
    }
    
    func dispAlert(_ msg: String){
        let alert = UIAlertController(title: "Error", message: msg, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { action -> Void in }
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
}
