//
//  HomeTableViewController.swift
//  PCL Admin
//
//  Created by Kevin on 6/28/21.
//

import UIKit

class HomeTableViewController: UITableViewController {
    
    let homePageVM = HomePageViewModel()
    var homeData : HomeData?
    var routeArr : [Int] = []
    var totalSpecimens : Int?
    var routeIdSelected = -1
    var driverId = ""
    var timer : Timer?
    
    @IBOutlet var countSpecimensLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        homePageVM.getHomeDetails { [weak self] (responseData) in
            guard let responseData = responseData, let self = self else { return }
            self.homeData = responseData
            for data in (self.homeData)! {
                if (self.routeArr.isEmpty) {
                    self.routeArr.append(data.routeNo!)
                } else {
                    if (self.routeArr.contains(data.routeNo!)) {
                        continue
                    } else {
                        self.routeArr.append(data.routeNo!)
                    }
                }
            }
            DispatchQueue.main.async {
                self.totalSpecimens = 0
                self.tableView.reloadData()
            }
        }
        self.runTimer()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
        self.runTimer()
    }
    
    func runTimer(){
        self.timer = Timer(fire: Date(), interval: 30.0, repeats: true, block: { (Timer) in
            self.homePageVM.getHomeDetails { [weak self] (responseData) in
                guard let responseData = responseData, let self = self else { return }
                self.homeData = responseData
                for data in (self.homeData)! {
                    if (self.routeArr.isEmpty) {
                        self.routeArr.append(data.routeNo!)
                    } else {
                        if (self.routeArr.contains(data.routeNo!)) {
                            continue
                        } else {
                            self.routeArr.append(data.routeNo!)
                        }
                    }
                }
                DispatchQueue.main.async {
                    self.totalSpecimens = 0
                    self.tableView.reloadData()
                }
            }
        })
        RunLoop.current.add(self.timer!, forMode: .default)
    }
    
    // MARK: - Table view data source
    
    @IBAction func logoutAction(_ sender: UIBarButtonItem) {
        let scene = self.view.window?.windowScene?.delegate as? SceneDelegate
        scene?.openLoginView()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return routeArr.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! HomeTableViewCell
        var accStatusString = ""
        var lastTime = ""
        var driver = ""
        var specCount = 0
        
        let k = routeArr[indexPath.row]
        
        for j in homeData! {
            if k == j.routeNo {
                switch j.status {
                case 0:
                    accStatusString += "🔘"
                case 1:
                    accStatusString += "🟢"
                    specCount += j.numberOfSpecimens!
                    totalSpecimens! += j.numberOfSpecimens!
                    if lastTime == ""{
                        lastTime = j.pickUpTime!
                    } else {
                        lastTime = lastTime > j.pickUpTime! ? lastTime : j.pickUpTime!
                    }
                case 2:
                    accStatusString += "🟡"
                case 3:
                    accStatusString += "🔴"
                case 4:
                    accStatusString += "⛔️"
                case 5:
                    accStatusString += "🟣"
                case 6:
                    accStatusString += "🔵"
                default:
                    accStatusString += ""
                }
                
                driver = j.updatedByDriver!
            }
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy'-'MM'-'dd' 'hh':'mm' 'a"
        let date = dateFormatter.date(from: lastTime)
        dateFormatter.dateStyle = .none
        dateFormatter.timeStyle = .short
        let displayTime = date == nil ? lastTime : dateFormatter.string(from: date!)
        
        
        cell.routeNoLabel.text = "\(k)"
        cell.accStatusLabel.text = accStatusString
        cell.pickedUpAtLabel.text = displayTime
        cell.pickedUpByLabel.text = driver
        cell.specimensCollectedLabel.text = "\(specCount)"
        cell.statusLabel.text = "On Time"
        cell.statusLabel.textColor = UIColor.green
        self.countSpecimensLabel.text = "\(self.totalSpecimens ?? 0)"
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        routeIdSelected = routeArr[indexPath.row]
        for i in homeData!{
            if i.routeNo == routeIdSelected {
                driverId = i.updatedByDriver!
                break
            }
        }
        performSegue(withIdentifier: "routeDetailsSegue", sender: self)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "routeDetailsSegue" {
            let nextVC = segue.destination as! HomeDetailsViewController
            nextVC.routeIdSelected = routeIdSelected
            nextVC.driverId = driverId
        }
    }
}
