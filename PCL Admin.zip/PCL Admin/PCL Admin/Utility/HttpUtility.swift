//
//  HttpUtility.swift
//  PCL Admin
//
//  Created by Kevin on 6/28/21.
//

import Foundation


struct URLConstants {
    static let loginURL = "https://gapinternationalwebapi20200521010239.azurewebsites.net/api/User/UserLogin"
    static let mainURL = "https://pclwebapi.azurewebsites.net/api/"
    static let detailsForAdmin = "Admin/GetDetailForAdmin"
    static let routeURL = "Route/GetRouteDetail/?RouteNumber="
    static let getDriverLocationURL = "Driver/GetDriverLocation?DriverId="
    static let getDriverListURL = "Driver/GetDriver"
    static let getCustomerListURL = "Customer/GetCustomer"
    static let getRoutesListURL = "Route/GetRoute"
    static let getVehicleListURL = "vehicle/GetVehicle"
    static let delDriverURL = "Driver/DeleteDriver/?DriverId="
    static let delCustomerURL = "Customer/DeleteCustomer/?CustomerId="
    static let delVehicleURL = "vehicle/DeleteVehicle?VehicleId="
    static let delRouteURL = "Route/DeleteRoute/?RouteNumber="
    static let addDriverURL = "Driver/AddDriver"
    static let updateDriverURL = "Driver/UpdateDriver"
    static let addVehicleURL = "vehicle/AddVehicle"
    static let updateVehicleURL = "vehicle/UpdateVehicle"
    static let addCustomerURL = "Customer/AddCustomer"
    static let updateCustomerURL = "Customer/UpdateCustomer"
    static let addRouteURL = "Route/AddRoute"
    static let updateRouteURL = "Route/EditRoute"
    static let availableDriverURL = "Driver/GetAvailableDriver"
    static let availableVehicleURL = "vehicle/GetAvailableVehicle"
    static let availableCustomerURL = "Customer/GetAvailableCustomer"
}

struct HttpUtility {
    
    static func getApiData <T: Decodable> (requestUrl: URL, resultType: T.Type, completion: @escaping(Result<T?,Error>) -> Void) {
        URLSession.shared.dataTask(with: requestUrl) { (data, response, error) in
            if let error = error {
                completion(.failure(error))
            }
            guard let response = response, let data = data else {
                let error = NSError(domain: "Error", code: 90, userInfo: ["Error":"Error while calling API"])
                completion(.failure(error))
                return
            }
            let statusCode = (response as? HTTPURLResponse)?.statusCode
            if statusCode == 200 {
                let decoder = JSONDecoder()
                do {
                    let result = try decoder.decode(T.self, from: data)
                    completion(.success(result))
                } catch {
                    print(error.localizedDescription)
                }
            } else {
                let error = NSError(domain: "Error", code: 90, userInfo: ["Error":"Error while calling API"])
                completion(.failure(error))
            }
        }.resume()
    }
    
    static func postApiData <T: Decodable> (requestUrl: URL, requestBody: Data?, resultType: T.Type, completion: @escaping(Result<T?,Error>) -> Void) {
        var request = URLRequest(url: requestUrl)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        if requestBody != nil {
            request.httpBody = requestBody
        }
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                completion(.failure(error))
            }
            guard let response = response, let data = data else {
                let error = NSError(domain: "Error", code: 90, userInfo: ["Error":"Error while calling API"])
                completion(.failure(error))
                return
            }
            let statusCode = (response as? HTTPURLResponse)?.statusCode
            if statusCode == 200 {
                let decoder = JSONDecoder()
                do {
                    let result = try decoder.decode(T.self, from: data)
                    completion(.success(result))
                } catch {
                    print(error.localizedDescription)
                }
            } else {
                let error = NSError(domain: "Error", code: 90, userInfo: ["Error":"Error while calling API"])
                completion(.failure(error))
            }
        }.resume()
    }
}

