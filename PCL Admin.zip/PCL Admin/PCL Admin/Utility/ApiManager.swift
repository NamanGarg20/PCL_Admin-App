//
//  ApiManager.swift
//  PCL Admin
//
//  Created by Kevin on 7/1/21.
//

import Foundation

struct ApiManager {
    
    //MARK:- Login Screen
    static func loginUser(user: String, pass: String, completion: @escaping(APIResults?,Error?) -> Void) {
        let url = URLConstants.loginURL
        let requestUrl = URL(string: url)!
        let loginData = LoginModel(userName: user, password: pass)
        
        let encoder = JSONEncoder()
        
        do {
            let jsonLoginData = try encoder.encode(loginData)
            
            HttpUtility.postApiData(requestUrl: requestUrl, requestBody: jsonLoginData, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
                switch result {
                case .success(let responseData) :
                    completion(responseData,nil)
                case .failure(let error) :
                    completion(nil,error)
                }
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
    //MARK:- Home Screen
    static func getHomePageDetails(completion: @escaping(HomeData?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.detailsForAdmin
        let requestUrl = URL(string: url)!
        
        HttpUtility.getApiData(requestUrl: requestUrl, resultType: HomeData.self) { (result : Result<HomeData?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func getRouteInfo(routeId: Int, completion: @escaping(RouteData?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.routeURL + "\(routeId)"
        let requestUrl = URL(string: url)!
        
        HttpUtility.postApiData(requestUrl: requestUrl, requestBody: nil, resultType: RouteData.self) { (result: Result<RouteData?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    //MARK:- Settings Screen
    //MARK:- Driver
    static func getDriverLocation(driverId: String, completion: @escaping(DriverLocationData?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.getDriverLocationURL + driverId
        let requestUrl = URL(string: url)!
        
        HttpUtility.getApiData(requestUrl: requestUrl, resultType: DriverLocationData.self) { (result : Result<DriverLocationData?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func getDriverList(completion: @escaping(DriverListData?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.getDriverListURL
        let requestUrl = URL(string: url)!
        
        HttpUtility.getApiData(requestUrl: requestUrl, resultType: DriverListData.self) { (result : Result<DriverListData?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func getAvailableDriverList(completion: @escaping(DriverListData?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.availableDriverURL
        let requestUrl = URL(string: url)!
        
        HttpUtility.getApiData(requestUrl: requestUrl, resultType: DriverListData.self) { (result : Result<DriverListData?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func delDriver(driverId: Int, completion: @escaping(APIResults?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.delDriverURL + "\(driverId)"
        let requestUrl = URL(string: url)!
        
        HttpUtility.postApiData(requestUrl: requestUrl, requestBody: nil, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func addDriver(firstName: String, lastName: String, phoneNo: String, completion: @escaping(APIResults?,Error?) -> Void){
        let url = URLConstants.mainURL + URLConstants.addDriverURL
        let requestUrl = URL(string: url)!
        let driverData = DriverModel(driverId: nil, firstName: firstName, lastName: lastName, phoneNumber: phoneNo)
        
        let encoder = JSONEncoder()
        
        do {
            let jsonDriverData = try encoder.encode(driverData)
            
            HttpUtility.postApiData(requestUrl: requestUrl, requestBody: jsonDriverData, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
                switch result {
                case .success(let responseData) :
                    completion(responseData,nil)
                case .failure(let error) :
                    completion(nil,error)
                }
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
    static func updateDriver(driverId: Int, firstName: String, lastName: String, phoneNo: String, completion: @escaping(APIResults?,Error?) -> Void){
        let url = URLConstants.mainURL + URLConstants.updateDriverURL
        let requestUrl = URL(string: url)!
        let driverData = DriverModel(driverId: driverId, firstName: firstName, lastName: lastName, phoneNumber: phoneNo)
        
        let encoder = JSONEncoder()
        
        do {
            let jsonDriverData = try encoder.encode(driverData)
            
            HttpUtility.postApiData(requestUrl: requestUrl, requestBody: jsonDriverData, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
                switch result {
                case .success(let responseData) :
                    completion(responseData,nil)
                case .failure(let error) :
                    completion(nil,error)
                }
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
    //MARK:- Customer
    static func getCustomerList(completion: @escaping(CustomerListData?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.getCustomerListURL
        let requestUrl = URL(string: url)!
        
        HttpUtility.getApiData(requestUrl: requestUrl, resultType: CustomerListData.self) { (result : Result<CustomerListData?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func getAvailableCustomerList(completion: @escaping(CustomerListData?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.availableCustomerURL
        let requestUrl = URL(string: url)!
        
        HttpUtility.getApiData(requestUrl: requestUrl, resultType: CustomerListData.self) { (result : Result<CustomerListData?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func delCustomer(custId: Int, completion: @escaping(APIResults?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.delCustomerURL + "\(custId)"
        let requestUrl = URL(string: url)!
        
        HttpUtility.postApiData(requestUrl: requestUrl, requestBody: nil, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func addCustomer(city: String, customerName: String, lat: Double, log: Double, pickUp: String, state: String, streetAddress: String, zip: Int, completion: @escaping(APIResults?,Error?) -> Void){
        let url = URLConstants.mainURL + URLConstants.addCustomerURL
        let requestUrl = URL(string: url)!
        let customerData = CustomerModel(city: city, customerName: customerName, pickupTime: pickUp, state: state, streetAddress: streetAddress, lat: lat, log: log, zip: zip, custId: nil)
        
        let encoder = JSONEncoder()
        
        do {
            let jsonCustomerData = try encoder.encode(customerData)
            
            HttpUtility.postApiData(requestUrl: requestUrl, requestBody: jsonCustomerData, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
                switch result {
                case .success(let responseData) :
                    completion(responseData,nil)
                case .failure(let error) :
                    completion(nil,error)
                }
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
    static func updateCustomer(custId: Int, city: String, customerName: String, lat: Double, log: Double, pickUp: String, state: String, streetAddress: String, zip: Int, completion: @escaping(APIResults?,Error?) -> Void){
        let url = URLConstants.mainURL + URLConstants.updateCustomerURL
        let requestUrl = URL(string: url)!
        let customerData = CustomerModel(city: city, customerName: customerName, pickupTime: pickUp, state: state, streetAddress: streetAddress, lat: lat, log: log, zip: zip, custId: custId)
        
        let encoder = JSONEncoder()
        
        do {
            let jsonCustomerData = try encoder.encode(customerData)
            
            HttpUtility.postApiData(requestUrl: requestUrl, requestBody: jsonCustomerData, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
                switch result {
                case .success(let responseData) :
                    completion(responseData,nil)
                case .failure(let error) :
                    completion(nil,error)
                }
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
    //MARK:- Vehicle
    static func getVehicleList(completion: @escaping(VehicleListData?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.getVehicleListURL
        let requestUrl = URL(string: url)!
        
        HttpUtility.getApiData(requestUrl: requestUrl, resultType: VehicleListData.self) { (result : Result<VehicleListData?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func getAvailableVehicleList(completion: @escaping(VehicleListData?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.availableVehicleURL
        let requestUrl = URL(string: url)!
        
        HttpUtility.getApiData(requestUrl: requestUrl, resultType: VehicleListData.self) { (result : Result<VehicleListData?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func delVehicle(vehicleId: Int, completion: @escaping(APIResults?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.delVehicleURL + "\(vehicleId)"
        let requestUrl = URL(string: url)!
        
        HttpUtility.postApiData(requestUrl: requestUrl, requestBody: nil, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func addVehicle(manufacturer: String, model: String, plateNum: String, completion: @escaping(APIResults?,Error?) -> Void){
        let url = URLConstants.mainURL + URLConstants.addVehicleURL
        let requestUrl = URL(string: url)!
        let vehicleData = VehicleModel(manufacturer: manufacturer, model: model, plateNumber: plateNum, vehicleID: nil)
        
        let encoder = JSONEncoder()
        
        do {
            let jsonVehicleData = try encoder.encode(vehicleData)
            HttpUtility.postApiData(requestUrl: requestUrl, requestBody: jsonVehicleData, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
                switch result {
                case .success(let responseData) :
                    completion(responseData,nil)
                case .failure(let error) :
                    completion(nil,error)
                }
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
    static func updateVehicle(manufacturer: String, model: String, plateNum: String, vehicleId: Int, completion: @escaping(APIResults?,Error?) -> Void){
        let url = URLConstants.mainURL + URLConstants.updateVehicleURL
        let requestUrl = URL(string: url)!
        let vehicleData = VehicleModel(manufacturer: manufacturer, model: model, plateNumber: plateNum, vehicleID: vehicleId)
        
        let encoder = JSONEncoder()
        
        do {
            let jsonVehicleData = try encoder.encode(vehicleData)
            HttpUtility.postApiData(requestUrl: requestUrl, requestBody: jsonVehicleData, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
                switch result {
                case .success(let responseData) :
                    completion(responseData,nil)
                case .failure(let error) :
                    completion(nil,error)
                }
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
    //MARK:- Route
    static func getRoutesList(completion: @escaping(RouteListData?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.getRoutesListURL
        let requestUrl = URL(string: url)!
        
        HttpUtility.getApiData(requestUrl: requestUrl, resultType: RouteListData.self) { (result : Result<RouteListData?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func delRoute(routeNo: Int, completion: @escaping(APIResults?,Error?) -> Void) {
        let url = URLConstants.mainURL + URLConstants.delRouteURL + "\(routeNo)"
        let requestUrl = URL(string: url)!
        
        HttpUtility.postApiData(requestUrl: requestUrl, requestBody: nil, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
            switch result {
            case .success(let responseData) :
                completion(responseData,nil)
            case .failure(let error) :
                completion(nil,error)
            }
        }
    }
    
    static func addRoute(customerID: String, vehicleNo: String, routeName: String, driverId: Int , completion: @escaping(APIResults?,Error?) -> Void){
        let url = URLConstants.mainURL + URLConstants.addRouteURL
        let requestUrl = URL(string: url)!
        let routeData = RouteModel(customerID: customerID, vehicleNo: vehicleNo, routeName: routeName, driverID: driverId, routeNo: nil)
        
        let encoder = JSONEncoder()
        
        do {
            let jsonRouteData = try encoder.encode(routeData)
            HttpUtility.postApiData(requestUrl: requestUrl, requestBody: jsonRouteData, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
                switch result {
                case .success(let responseData) :
                    completion(responseData,nil)
                case .failure(let error) :
                    completion(nil,error)
                }
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
    static func updateRoute(customerID: String, vehicleNo: String, routeName: String, driverId: Int, routeNo: Int, completion: @escaping(APIResults?,Error?) -> Void){
        let url = URLConstants.mainURL + URLConstants.updateRouteURL
        let requestUrl = URL(string: url)!
        let routeData = RouteModel(customerID: customerID, vehicleNo: vehicleNo, routeName: routeName, driverID: driverId, routeNo: routeNo)
        
        let encoder = JSONEncoder()
        
        do {
            let jsonRouteData = try encoder.encode(routeData)
            HttpUtility.postApiData(requestUrl: requestUrl, requestBody: jsonRouteData, resultType: APIResults.self) { (result : Result<APIResults?, Error>) in
                switch result {
                case .success(let responseData) :
                    completion(responseData,nil)
                case .failure(let error) :
                    completion(nil,error)
                }
            }
        } catch {
            print(error.localizedDescription)
        }
    }
}
