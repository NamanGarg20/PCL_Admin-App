//
//  HomePageViewModel.swift
//  PCL Admin
//
//  Created by Kevin on 6/28/21.
//

import Foundation

struct HomePageViewModel {
    
    func getHomeDetails(completion : @escaping(HomeData?) -> Void) {
        ApiManager.getHomePageDetails { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
}
