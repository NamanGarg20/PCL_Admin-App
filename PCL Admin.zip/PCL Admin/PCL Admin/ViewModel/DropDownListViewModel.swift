//
//  DropDownListViewModel.swift
//  PCL Admin
//
//  Created by NAMAN GARG on 7/6/21.
//

import Foundation

struct DropDownListViewModel {
    func getAvailableDriverList(completion: @escaping(DriverListData?) -> Void) {
        ApiManager.getAvailableDriverList { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func getAvailableCustomerList(completion: @escaping(CustomerListData?) -> Void) {
        ApiManager.getAvailableCustomerList { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func getAvailableVehicleList(completion: @escaping(VehicleListData?) -> Void) {
        ApiManager.getAvailableVehicleList { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    
}
