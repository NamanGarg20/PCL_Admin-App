//
//  HomeDetailsViewModel.swift
//  PCL Admin
//
//  Created by Kevin on 6/29/21.
//

import Foundation

struct HomeDetailsViewModel {
    
    func getRouteInfo(routeId: Int, completion: @escaping(RouteData?) -> Void) {
        ApiManager.getRouteInfo(routeId: routeId) { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func getDriverLocationInfo(driverId: String, completion: @escaping(DriverLocationData?) -> Void) {
        ApiManager.getDriverLocation(driverId: driverId) { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
}
