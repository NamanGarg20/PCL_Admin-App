//
//  AddUpdateViewModel.swift
//  PCL Admin
//
//  Created by Kevin on 7/1/21.
//

import Foundation
import CoreLocation

struct AddUpdateViewModel {
    
    func addDriver(firstName: String, lastName: String, phoneNo: String, completion: @escaping(APIResults?) -> Void){
        ApiManager.addDriver(firstName: firstName, lastName: lastName, phoneNo: phoneNo) { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func updateDriver(driverId: Int, firstName: String, lastName: String, phoneNo: String, completion: @escaping(APIResults?) -> Void){
        
        ApiManager.updateDriver(driverId: driverId, firstName: firstName, lastName: lastName, phoneNo: phoneNo) { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func addVehicle(manufacturer: String, model: String, plateNum: String, completion: @escaping(APIResults?) -> Void){
        ApiManager.addVehicle(manufacturer: manufacturer, model: model, plateNum: plateNum) {(responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    
    func updateVehicle(manufacturer: String, model: String, plateNum: String, vehicleId: Int, completion: @escaping(APIResults?) -> Void){
        ApiManager.updateVehicle(manufacturer: manufacturer, model: model, plateNum: plateNum, vehicleId: vehicleId) { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func addCustomer(city: String, customerName: String, pickUp: String, state: String, streetAddress: String, zip: Int, completion: @escaping(APIResults?) -> Void){
        let address = streetAddress + ", " +  city + ", " + state + ", " + String(zip)
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(address, completionHandler: {(placemarks, error) -> Void in
            if((error) != nil){
                print("Error", error ?? "")
            }
            if let placemark = placemarks?.first {
                let coordinates:CLLocationCoordinate2D = placemark.location!.coordinate
                ApiManager.addCustomer(city: city, customerName: customerName, lat: coordinates.latitude, log: coordinates.longitude, pickUp: pickUp, state: state, streetAddress: streetAddress, zip: zip) { (responseData, error) in
                    if responseData != nil && error == nil {
                        completion(responseData)
                    }
                }
            }
        })
        
    }
    
    func updateCustomer(custId: Int, city: String, customerName: String, pickUp: String, state: String, streetAddress: String, zip: Int, completion: @escaping(APIResults?) -> Void){
        let address = streetAddress + ", " +  city + ", " + state + ", " + String(zip)
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(address, completionHandler: {(placemarks, error) -> Void in
            if((error) != nil){
                print("Error", error ?? "")
            }
            if let placemark = placemarks?.first {
                let coordinates:CLLocationCoordinate2D = placemark.location!.coordinate
                ApiManager.updateCustomer(custId: custId, city: city, customerName: customerName, lat: coordinates.latitude, log: coordinates.longitude, pickUp: pickUp, state: state, streetAddress: streetAddress, zip: zip) { (responseData, error) in
                    if responseData != nil && error == nil {
                        completion(responseData)
                    }
                }
            }
        })
    }
    
    
    func addRoute(customerID: String, vehicleNo: String, routeName: String, driverId: Int , completion: @escaping(APIResults?) -> Void){
        
        ApiManager.addRoute(customerID: customerID, vehicleNo: vehicleNo, routeName: routeName, driverId: driverId) { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
        
    }
    
    func updateRoute(customerID: String, vehicleNo: String, routeName: String, driverId: Int, routeNo: Int, completion: @escaping(APIResults?) -> Void){
        
        ApiManager.updateRoute(customerID: customerID, vehicleNo: vehicleNo, routeName: routeName, driverId: driverId, routeNo: routeNo) { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            } 
        }
    }
    
    
}
