//
//  ListTableViewModel.swift
//  PCL Admin
//
//  Created by Kevin on 6/30/21.
//

import Foundation

struct ListTableViewModel {
    func getDriverList(completion: @escaping(DriverListData?) -> Void) {
        ApiManager.getDriverList { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func delDriver(driverId: Int, completion: @escaping(APIResults?) -> Void) {
        ApiManager.delDriver(driverId: driverId) { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func getCustomerList(completion: @escaping(CustomerListData?) -> Void) {
        ApiManager.getCustomerList { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func delCustomer(custId: Int, completion: @escaping(APIResults?) -> Void) {
        ApiManager.delCustomer(custId: custId) { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func getVehicleList(completion: @escaping(VehicleListData?) -> Void) {
        ApiManager.getVehicleList { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func delVehicle(vehicleId: Int, completion: @escaping(APIResults?) -> Void) {
        ApiManager.delVehicle(vehicleId: vehicleId) { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func getRoutesList(completion: @escaping(RouteListData?) -> Void) {
        ApiManager.getRoutesList { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
    func delRoute(routeNo: Int, completion: @escaping(APIResults?) -> Void) {
        ApiManager.delRoute(routeNo: routeNo) { (responseData, error) in
            if responseData != nil && error == nil {
                completion(responseData)
            }
        }
    }
    
}
