//
//  DriverModel.swift
//  PCL Admin
//
//  Created by Kevin on 7/1/21.
//

import Foundation

struct DriverModel : Encodable {
    let driverId : Int?
    let firstName, lastName, phoneNumber : String?
    
    enum CodingKeys : String, CodingKey {
        case driverId = "DriverId"
        case firstName = "FirstName"
        case lastName = "LastName"
        case phoneNumber = "PhoneNumber"
    }
}
