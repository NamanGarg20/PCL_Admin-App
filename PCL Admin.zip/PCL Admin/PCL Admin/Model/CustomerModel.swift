//
//  CustomerModel.swift
//  PCL Admin
//
//  Created by Kevin on 7/1/21.
//

import Foundation

struct CustomerModel: Encodable {
    let city, customerName, pickupTime, state, streetAddress : String?
    let lat, log : Double?
    let zip, custId: Int?
    
    enum CodingKeys: String, CodingKey {
        case city = "City"
        case customerName = "CustomerName"
        case pickupTime = "PickupTime"
        case state = "State"
        case streetAddress = "StreetAddress"
        case zip = "Zip"
        case lat = "Cust_Lat"
        case log = "Cust_Log"
        case custId = "CustomerId"
    }
}
