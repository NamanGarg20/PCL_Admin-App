//
//  DriverListData.swift
//  PCL Admin
//
//  Created by Kevin on 6/30/21.
//

import Foundation

struct DriverListDatum: Decodable {
    let driverID: Int?
    let driverName, phoneNumber: String?

    enum CodingKeys: String, CodingKey {
        case driverID = "DriverId"
        case driverName = "DriverName"
        case phoneNumber = "PhoneNumber"
    }
}

typealias DriverListData = [DriverListDatum]
