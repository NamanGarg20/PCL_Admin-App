//
//  DriverLocationData.swift
//  PCL Admin
//
//  Created by Kevin on 6/30/21.
//

import Foundation

struct DriverLocationDatum: Decodable {
    let lat, log: Double?
    let geofence: Bool?

    enum CodingKeys: String, CodingKey {
        case lat = "Lat"
        case log = "Log"
        case geofence = "Geofence"
    }
}

typealias DriverLocationData = [DriverLocationDatum]
