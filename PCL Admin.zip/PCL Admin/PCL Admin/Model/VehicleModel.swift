//
//  VehicleModel.swift
//  PCL Admin
//
//  Created by NAMAN GARG on 7/1/21.
//

import Foundation

struct VehicleModel: Encodable {
    let manufacturer, model, plateNumber: String?
    let vehicleID: Int?

    enum CodingKeys: String, CodingKey {
        case manufacturer = "Manufacturer"
        case model = "Model"
        case plateNumber = "PlateNumber"
        case vehicleID = "VehicleId"
    }
}
