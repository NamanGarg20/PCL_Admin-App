//
//  CustomerListData.swift
//  PCL Admin
//
//  Created by Kevin on 6/30/21.
//

import Foundation

struct CustomerListDatum: Decodable {
    let customerID: Int?
    let customerName, streetAddress, city, state: String?
    let zip, pickUpTime: String?
    let isSelected : Bool?
    
    enum CodingKeys: String, CodingKey {
        case customerID = "CustomerId"
        case customerName = "CustomerName"
        case streetAddress = "StreetAddress"
        case city = "City"
        case state = "State"
        case zip = "Zip"
        case pickUpTime = "PickUpTime"
        case isSelected = "IsSelected"
    }
}

typealias CustomerListData = [CustomerListDatum]
