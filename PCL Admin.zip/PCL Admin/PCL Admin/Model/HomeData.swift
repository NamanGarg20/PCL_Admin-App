//
//  HomeData.swift
//  PCL Admin
//
//  Created by Kevin on 6/28/21.
//

import Foundation

struct HomeDatum: Decodable {
    let tranID, routeNo, customerID, status: Int?
    let pickUpDt, pickUpTime: String?
    let numberOfSpecimens: Int?
    let createdDate, updatedByDriver: String?

    enum CodingKeys: String, CodingKey {
        case tranID = "TranId"
        case routeNo = "RouteNo"
        case customerID = "CustomerId"
        case status = "Status"
        case pickUpDt = "PickUp_Dt"
        case pickUpTime = "PickUp_Time"
        case numberOfSpecimens = "NumberOfSpecimens"
        case createdDate = "CreatedDate"
        case updatedByDriver = "UpdatedByDriver"
    }
}

typealias HomeData = [HomeDatum]
