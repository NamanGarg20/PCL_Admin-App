//
//  APIResults.swift
//  PCL Admin
//
//  Created by Kevin on 6/30/21.
//

import Foundation

struct APIResults : Decodable {
    let result: String?
    
    enum CodingKeys: String, CodingKey {
        case result = "Result"
    }
}
