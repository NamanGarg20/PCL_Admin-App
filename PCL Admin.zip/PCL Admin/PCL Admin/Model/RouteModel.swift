//
//  RouteModel.swift
//  PCL Admin
//
//  Created by NAMAN GARG on 7/2/21.
//

import Foundation

// MARK: - RouteModel
struct RouteModel: Codable {
    let customerID, vehicleNo, routeName: String?
    let driverID, routeNo: Int?

    enum CodingKeys: String, CodingKey {
        case customerID = "CustomerID"
        case vehicleNo = "VehicleNo"
        case routeName = "RouteName"
        case driverID = "DriverId"
        case routeNo = "RouteNo"
    }
}
