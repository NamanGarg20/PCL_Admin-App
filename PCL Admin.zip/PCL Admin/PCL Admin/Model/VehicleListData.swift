//
//  VehicleListData.swift
//  PCL Admin
//
//  Created by Kevin on 6/30/21.
//

import Foundation

struct VehicleListDatum: Decodable {
    let vehicleID: Int?
    let plateNumber, manufacturer, model: String?

    enum CodingKeys: String, CodingKey {
        case vehicleID = "VehicleId"
        case plateNumber = "PlateNumber"
        case manufacturer = "Manufacturer"
        case model = "Model"
    }
}

typealias VehicleListData = [VehicleListDatum]
