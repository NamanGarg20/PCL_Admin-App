//
//  LoginModel.swift
//  PCL Admin
//
//  Created by Kevin on 7/12/21.
//

import Foundation

struct LoginModel : Encodable {
    let userName, password: String?

    enum CodingKeys: String, CodingKey {
        case userName = "UserName"
        case password = "Password"
    }
}
