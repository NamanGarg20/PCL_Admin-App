//
//  RouteListData.swift
//  PCL Admin
//
//  Created by Kevin on 6/30/21.
//

import Foundation

struct RoutesListDatum: Decodable {
    let route: Routes?
    let customer: [Customers]?

    enum CodingKeys: String, CodingKey {
        case route = "Route"
        case customer = "Customer"
    }
}

struct Customers: Decodable {
    let customerID: Int?
    let customerName, streetAddress, city, state: String?
    let zip: String?


    enum CodingKeys: String, CodingKey {
        case customerID = "CustomerId"
        case customerName = "CustomerName"
        case streetAddress = "StreetAddress"
        case city = "City"
        case state = "State"
        case zip = "Zip"
    }
}

struct Routes: Decodable {
    let routeNo: Int?
    let routeName: String?
    let driverID: Int?
    let driverName, vehicleNo: String?

    enum CodingKeys: String, CodingKey {
        case routeNo = "RouteNo"
        case routeName = "RouteName"
        case driverID = "DriverId"
        case driverName = "DriverName"
        case vehicleNo = "VehicleNo"
    }
}

typealias RouteListData = [RoutesListDatum]
